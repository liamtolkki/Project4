# Project4 (AVL Tree)
This project is an implementation of the AVL tree data structure. 
AVL tree is a self-balancing binary search tree that guarantees a 
logarithmic time complexity for basic operations such as search, 
insert, and delete. This implementation uses C++ programming language.

# Dependancy Tree (file/class names):

- ProjectrDriver
    - AVLTree
        - Node